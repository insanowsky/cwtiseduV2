<!DOCTYPE html>
<head>
<meta charset="utf-8"> 
<title>SQL - Ćwiczenia</title>
<style>
body {
	background-color: black;
	color: white;
	font-size: 20px;
}
table {
	border: 1px solid yellow;
	border-collapse: collapse;
	empty-cells: show;

}
td, th {
	border: 1px solid yellow;	
	padding: 5px 10px;
}
th {
	background-color: #555555;
}
h3 {
	color: yellow;
}
input.a {
	width: 800px;
	font-size: 18px;
}
</style>
</head>

<body>
<center>

<h1>Technik informatyk w Strzelinie</h1>

<form action="sel.php" method="post" name="f">
	Nazwa bazy: &nbsp;&nbsp;<input type="text" name="baza" autocomplete="off" required><br><br>
	Zapytanie SQL: &nbsp;&nbsp;<input type="text" name="zapyt" class="a" autocomplete="off" required><br><br>

	<input type="submit" name="submit" value="Wyślij zapytanie">

</form>

<?php 
if (isset($_POST["submit"]))
{
	$baza = $_POST['baza'];
	$sql = $_POST['zapyt'];
	
	echo "<h3>$sql</h3>";
	echo '<table>';

	$con=mysqli_connect('localhost', 'root', '');
	mysqli_query($con, "SET CHARSET utf8");
	mysqli_query($con, "SET NAMES 'utf8' COLLATE 'utf8_polish_ci'");
	mysqli_select_db($con, $baza);
	
	$result=mysqli_query($con,$sql);
	
	$s = substr ($sql,0,6);
	$s = strtoupper ($s);

	if ($result && $s=='SELECT')
	{
		$fieldinfo=mysqli_fetch_fields($result);

		echo '<tr>';
		foreach ($fieldinfo as $a)
		{
			echo '<th>';
			$k[] = $a->name;
			echo $a->name.'</th>';
		}	
		echo '</tr>';
		
		while ($p = mysqli_fetch_array($result))
		{
			echo '<tr>';
			foreach ($k as $n)
			{
				echo '<td>';
				echo $p[$n];
				echo '</td>';
			}	
			echo '</tr>';		
		}
	}
	mysqli_close($con);
}
?>

</table>

</center>
</body>
</html>
